let modal = new bootstrap.Modal(document.getElementById('modal'));

modal.show();