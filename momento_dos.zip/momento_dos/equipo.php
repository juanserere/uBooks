
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Equipo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
</head>
<body>
<div class="container">
<br>
 <center><h1>ADMINISTRACION DE EQUIPOS</h1></center> 
 <br><br> 
 <div class="row">
    
    <div class="col" >
    <a href="addE.php">AGREGAR EQUIPO </a>
    </div>
    <div class="col">
    <a href="listE.php">VER EQUIPOS</a> 
    </div>
    <div class="col" >
    <a href="index.php">VOLVER A INICIO </a> 
    <br> 

    

    </div>
    <br><br>

    
  <img src="img/Liga.png" class="img-fluid" alt="...">
    
</div> 
<br><br>

<div class="row row-cols-4 color-red">
    <div class="col">Contactenos</div>
    <div class="col">Email Equipos@hp.com</div>
    <div class="col">Direciion</div>
    <div class="col">Telefonos</div>
  </div>
       
    
</div>
       
</body>
</html>